icinga2-vim
===========

icinga2 Configuration ^_^ &amp; VIM

forked from https://github.com/Icinga/icinga2/tree/master/tools/syntax/vim
